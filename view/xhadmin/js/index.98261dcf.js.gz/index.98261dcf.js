import{o as e,g as o}from"./.pnpm.a2573b0b.js";import{d as r}from"./index.c12940d1.js";const c={};function n(t,s){return e(),o("div",null," 重定向页面 ")}const f=r(c,[["render",n]]);export{f as default};
