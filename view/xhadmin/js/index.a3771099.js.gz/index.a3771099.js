import{o as e,n}from"./.pnpm.7ed59634.js";import{d as o}from"./index.cb044cbd.js";const r={};function c(t,s){return e(),n("div",null," 重定向页面 ")}const f=o(r,[["render",c]]);export{f as default};
