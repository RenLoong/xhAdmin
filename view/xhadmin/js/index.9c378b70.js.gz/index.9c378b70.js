import{o as e,n as c}from"./.pnpm.cb614f95.js";import{c as n}from"./index.3f7b98b0.js";const o={};function r(t,s){return e(),c("div",null," 重定向页面 ")}const f=n(o,[["render",r]]);export{f as default};
